export const API_URL = import.meta.env.VITE_API_URL || 'https://hello-who--irumzainab3.replit.app';
